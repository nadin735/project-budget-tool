# Projekt-Budget-Tool — Deployment

Dieses Projekt lässt sich kostenlos auf **Vercel** hosten und ist direkt mit
GitHub verbunden (jeder Push aktualisiert automatisch die Live-Seite).

## 1. Auf GitHub stellen

```bash
cd projekt-budget-tool
git init
git add .
git commit -m "Initial commit"
```

Dann auf github.com ein neues (leeres) Repository anlegen und den Anweisungen
dort folgen, um dieses lokale Projekt hochzuladen (`git remote add origin ...`,
`git push -u origin main`).

## 2. Anthropic API-Key besorgen

Falls noch nicht vorhanden: auf [console.anthropic.com](https://console.anthropic.com)
einen API-Key erstellen (Get API Keys -> Create Key). Diesen Key **niemals**
in den Code oder auf GitHub schreiben — er kommt gleich als Umgebungsvariable
ins Hosting.

## 3. Bei Vercel deployen

1. Auf [vercel.com](https://vercel.com) mit dem GitHub-Account einloggen.
2. "Add New… → Project" → das gerade erstellte GitHub-Repo auswählen → Import.
3. Vercel erkennt Vite automatisch, Build-Einstellungen können so bleiben.
4. Unter **Environment Variables** hinzufügen:
   - Name: `ANTHROPIC_API_KEY`
   - Value: der Key aus Schritt 2
5. "Deploy" klicken. Nach ca. 1 Minute ist die Seite live unter einer
   `*.vercel.app`-Adresse (später kann eine eigene Domain verbunden werden).

## Wie die Stücke zusammenspielen

- `src/App.jsx` — die komplette App (identisch mit der Claude-Artifact-Version).
  Erkennt automatisch, dass sie *nicht* in Claude läuft, und:
  - nutzt `localStorage` statt der Claude-eigenen Speicherung
  - schickt PDF-Analyse-Anfragen an `/api/claude` statt direkt an Anthropic
- `api/claude.js` — eine Vercel Serverless Function. Nimmt die Anfrage vom
  Frontend entgegen, hängt den echten API-Key (aus der Umgebungsvariable)
  an und leitet sie an `api.anthropic.com` weiter. Der Key ist dadurch nie
  im Browser sichtbar.

## Lokal testen (optional, vor dem Deployment)

```bash
npm install
npm run dev
```

PDF-Analyse funktioniert lokal nur, wenn zusätzlich `ANTHROPIC_API_KEY` als
Umgebungsvariable gesetzt ist und die App über `vercel dev` (statt `vite`
allein) läuft, da `vite dev` die `/api`-Funktionen nicht automatisch bereitstellt.
Für reines UI-Testen ohne PDF-Funktion reicht `npm run dev`.

## Wichtiger Hinweis zur Sicherheit

Der Login-Bereich in diesem Tool ist **bewusst nur eine Demo-Oberfläche**:
Passwörter werden ausschließlich lokal im Browser (`localStorage`) geprüft,
nicht auf einem Server. Für echte Kundenkonten mit echtem Passwortschutz
wird zusätzlich ein Auth-Anbieter wie Supabase Auth oder Firebase
Authentication benötigt — das ist mit dem aktuellen Stand noch nicht
umgesetzt.
